package homework0;

/**
 * This is a simple object that has a volume.
 */
public class Ball {
	
    /**
     * @requires volume > 0
     * @modifies this
     * @effects Creates and initializes new Ball object with the specified
     *  		volume.
     */
    public Ball(double volume) {
		// TODO: Add your code here
		
    }


	/**
	 * @requires volume > 0
	 * @modifies this
	 * @effects Sets the volume of the Ball.
	 */
	public void setVolume(double volume) {
		// TODO: Add your code here
		
	}


    /**
     * @return the volume of the Ball.
     */
    public double getVolume() {
		// TODO: Add your code here
		
    }
}