package homework0;

/**
	A Coin can have a value of 0.01, 0.05, 0.1, 0.25, 0.5, 1
 */
public class Coin {
	private double value;
	
    /**
     * @requires value in {0.01, 0.05, 0.1, 0.25, 0.5, 1}
     * @effects Creates and initializes new Coin with the given value
     * 
     */
    public Coin(double value) {
    	//TODO
    }


    /**
     * @return the value of the Coin
     */
    public double getValue() {
    	//TODO
    }
    
    //
}